Proyecto realizado por:

	Mariano Rodríguez 12-10892
	Pablo Gonzalez 13-10575



El proyecto guarda los resultados de las corridas en carpetas, donde cada caso
lo guarda como "organismoX.txt" siendo X el número del orden en el cual se 
corrió el caso, comenzando desde 0 hasta N-1 siendo N el número de casos
(se cuentan como N numero de casos la suma de los casos de todos los .txt dados
como casos de prueba.)

Todo lo realizado en el proyecto está basado por el documento Proy01.pdf
subido al Aula Virtual, se incluye entre los archivos la versión del PDF con la
cual se trabajó en el proyecto.


Se entregan dos versiones del proyecto:

Proyecto01_PDF.py: Es donde se busca seguir al pie de la letra lo solicitado en
el proyecto y guarda los resultados en /resultados/

Proyecto01_Sin_Complemento.py: Corre prácticamente igual que Proyecto01_PDF.py
con la diferencia de que al momento de traducir el ADN a ARNt, lo hace desde
la cadena de ADN dada y no desde el complemento de la cadena de ADN dada, esto
se hace debido a los diferentes resultados que resultan al corrrer el programa
de una forma u otra. Este archivo guarda los resultados en 
/resultados_sin_complemento/
